import { Token } from "../token";
import { Pipe, PipeTransform } from "@angular/core";
@Pipe({ name: "sort" })

export class Sort implements PipeTransform { 
    transform(items: any[], ): any[] { 
        return items.sort((tokenA:Token,tokenB:Token)=>{
            if(tokenA.queueNumber>tokenB.queueNumber) return 1;
            else return -1;
        })
    }    }