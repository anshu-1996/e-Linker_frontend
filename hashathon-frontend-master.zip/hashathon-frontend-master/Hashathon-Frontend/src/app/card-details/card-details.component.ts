import { Component, Input, OnInit } from '@angular/core';
import { CardsService } from 'src/app/Services/cards.service';
import { Token } from '../token';
import { ActivatedRoute, Router } from '@angular/router';
import { FetchTracksService } from '../Services/fetch-tracks.service'
import { ITrack } from 'src/app/Interfaces/ITracks';


@Component({
  selector: 'app-card-details',
  templateUrl: './card-details.component.html',
  styleUrls: ['./card-details.component.scss']
})
export class CardDetailsComponent implements OnInit {
  @Input() evaluator_email: string;
  trackId: string;
  currentTrack: ITrack;
  ticketList: Token[];
  activeTicketList: Token[];
  public tracks = [];
  currentTicket: any

  constructor(private router: Router, private activatedRoute: ActivatedRoute, private fetchTracksService: FetchTracksService, private cardService: CardsService) { }

  ngOnInit(): void {

    this.currentTicket = JSON.parse(localStorage.getItem('activeToken')) || { name: "", token: "", status: "", track: "",comment:"" };

    this.activatedRoute.paramMap.subscribe(params => {
      this.trackId = <string>params.get('id');
      this.fetchTracksService.getTrackById(this.trackId).subscribe(data => this.currentTrack = data);
      setInterval(() => {
        this.fetchTracksService.getTicketList().subscribe(ticket => this.ticketList = ticket);
      }, 1000)

    });

    this.fetchTracksService.getTracks().subscribe(data => {
      this.tracks = data;
    });

  }

  AcceptCard(token) {
    this.cardService.acceptTicket(this.evaluator_email, token,this.currentTicket.comment).subscribe(data => {
      this.currentTicket = data;
      localStorage.setItem('activeToken', JSON.stringify(this.currentTicket));
      // this.Refresh();
    });

  }

  completedTickets(token) {
    this.cardService.confirmTicket(this.evaluator_email, token).subscribe(data => {
      this.currentTicket = data;
      localStorage.setItem('activeToken', JSON.stringify({ name: "", token: "", status: "", track: "", comment:"" }));
      alert("Ticket Completed");
      this.Refresh();
    });
  }

  declinedTickets(token){
    this.cardService.declineTicket(this.evaluator_email, token).subscribe(data => {
      this.currentTicket = data;
      localStorage.setItem('activeToken', JSON.stringify({ name: "", token: "", status: "", track: "" }));
      alert("Ticket Declined");
      this.Refresh();
    });
  }
  Refresh() {
    this.router.navigateByUrl('/RefreshComponent', { skipLocationChange: true }).then(() => { this.router.navigate(['/eval',this.evaluator_email]); console.log("res"); })
  }

}


