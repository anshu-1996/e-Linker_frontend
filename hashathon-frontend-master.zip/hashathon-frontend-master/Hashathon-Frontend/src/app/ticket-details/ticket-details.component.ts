import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import {FetchTracksService} from '../Services/fetch-tracks.service'
import { ITrack } from 'src/app/Interfaces/ITracks';

@Component({
  selector: 'app-ticket-details',
  templateUrl: './ticket-details.component.html',
  styleUrls: ['./ticket-details.component.scss']
})
export class TicketDetailsComponent implements OnInit {

  trackId:string;
  currentTrack:ITrack;
  ticketList:any;
  activeTicketList:any;
  public tracks = [];


  constructor(private router: Router,private activatedRoute:ActivatedRoute, private fetchTracksService:FetchTracksService ) { }

  ngOnInit(): void {
    this.activatedRoute.paramMap.subscribe(params=>{
      this.trackId = <string>params.get('id');
      this.fetchTracksService.getTrackById(this.trackId).subscribe(data =>this.currentTrack = data);
      this.fetchTracksService.getTicketList().subscribe(ticket => this.ticketList = ticket);
      this.fetchTracksService.getActiveTickets().subscribe(activeTicket =>{
        this.activeTicketList = activeTicket
        console.log(this.activeTicketList);
      });

    });

    this.fetchTracksService.getTracks().subscribe(data => {
      this.tracks = data;
    });

  }

}

