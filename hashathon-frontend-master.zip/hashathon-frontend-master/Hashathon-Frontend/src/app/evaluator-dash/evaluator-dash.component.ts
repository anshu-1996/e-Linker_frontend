import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import {VerifyEvaluatorService} from '../Services/verify-evaluator.service'

@Component({
  selector: 'app-evaluator-dash',
  templateUrl: './evaluator-dash.component.html',
  styleUrls: ['./evaluator-dash.component.scss']
})
export class EvaluatorDashComponent implements OnInit {
  evaluator_email;
  evaluator;
  constructor(private activatedRoute:ActivatedRoute, private verifyEvaluatorService:VerifyEvaluatorService) { }

  ngOnInit(): void {
    this.activatedRoute.paramMap.subscribe(params=>{
      this.evaluator_email = <string>params.get('email');
      console.log("eval: "+this.evaluator_email);
    });
    this.verifyEvaluatorService.verifyEvaluator(this.evaluator_email).subscribe(data => {
      this.evaluator = data;
      console.log("Current Evaluator: "+this.evaluator.name);
    });
  }

  

}
