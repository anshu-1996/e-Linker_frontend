import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EvaluatorDashComponent } from './evaluator-dash.component';

describe('EvaluatorDashComponent', () => {
  let component: EvaluatorDashComponent;
  let fixture: ComponentFixture<EvaluatorDashComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ EvaluatorDashComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(EvaluatorDashComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
