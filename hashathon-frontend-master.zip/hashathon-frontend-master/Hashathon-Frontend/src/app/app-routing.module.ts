import { NgModule } from '@angular/core';
import { Routes } from '@angular/router';
import { RouterModule } from '@angular/router';
import { AngularPageComponent } from './Components/angular-page/angular-page.component';
import { HomeComponent } from './Components/home/home.component';
import { HtmlpageComponent} from './Components/htmlpage/htmlpage.component'
import { EvaluatorDashboardComponent } from './evaluator-dashboard/evaluator-dashboard.component';

import { EvaluatorDashComponent } from './evaluator-dash/evaluator-dash.component';

import { LoginComponent } from './Components/login/login.component';


const routes: Routes = [

  { path: '', component: LoginComponent },
  { path: 'home/:email', component: HomeComponent },
  { path: 'HTML/:email/:id', component: HtmlpageComponent },

  { path: 'angular', component: AngularPageComponent },
  {path: 'eval/:email', component: EvaluatorDashComponent},

  { path: 'login', component: LoginComponent },
  { path: '**', component: LoginComponent }

];

@NgModule({
  declarations: [],
    imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
