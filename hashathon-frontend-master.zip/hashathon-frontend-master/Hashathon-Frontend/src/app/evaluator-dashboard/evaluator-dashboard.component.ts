import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-evaluator-dashboard',
  templateUrl: './evaluator-dashboard.component.html',
  styleUrls: ['./evaluator-dashboard.component.scss']
})
export class EvaluatorDashboardComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
