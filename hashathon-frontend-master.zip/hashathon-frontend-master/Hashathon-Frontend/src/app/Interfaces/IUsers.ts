export interface IUser{
    
    _id: string,
    name: string,
    email: string,
    comment: string,
    token: string,
    queueNumber:Number,
    status: Number,
    __v: Number
}