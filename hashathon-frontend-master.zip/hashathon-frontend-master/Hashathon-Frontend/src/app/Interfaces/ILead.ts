export interface ILead {

        name: string,
        email: string,
        _id: string,
        __v : number
}
