import { Component, OnInit } from '@angular/core';
import {ITrack} from '../../Interfaces/ITracks'
import {FetchTracksService} from '../../Services/fetch-tracks.service'
import {FetchLeadService} from '../../Services/fetch-lead.service'
import { ActivatedRoute, Router } from '@angular/router';
import { VerifyUserService } from 'src/app/Services/verify-user.service';

@Component({
  selector: 'app-tracks',
  templateUrl: './tracks.component.html',
  styleUrls: ['./tracks.component.scss']
})
export class TracksComponent implements OnInit {
  public tracks = [];


  constructor(private fetchTracksService:FetchTracksService, private router:Router,private activatedRoute:ActivatedRoute, private verifyUserService:VerifyUserService) { }
  user_email;
  currentUser;
  ngOnInit(): void {
    this.fetchTracksService.getTracks().subscribe(data => {
      this.tracks = data;
    });
    this.activatedRoute.paramMap.subscribe(params=>{
      this.user_email = <string>params.get('email');
      console.log("sideNav2: "+this.user_email);
    });
    this.verifyUserService.verifyUser(this.user_email).subscribe(data => {
      this.currentUser = data;
      console.log("Current User1:\n "+JSON.stringify(this.currentUser) );
    });
  }

  trackDetails( track:ITrack){
    this.router.navigate(['/HTML',this.currentUser.email,track._id])
  }


}
