import { Component, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { DialogServiceService } from '../../Services/dialog-service.service';
import { ActivatedRoute, Router } from '@angular/router';
import {FetchTracksService} from '../../Services/fetch-tracks.service'
import { ITrack } from 'src/app/Interfaces/ITracks';
import { VerifyUserService } from 'src/app/Services/verify-user.service';

@Component({
  selector: 'app-htmlcontent',
  templateUrl: './htmlcontent.component.html',
  styleUrls: ['./htmlcontent.component.scss']
})
export class HtmlcontentComponent implements OnInit {
  trackId:string;
  currentTrack:ITrack;
  ticketList:any;
  activeTicketList:any;
  public tracks = [];
  user_email;
  currentUser;
  currentDate = new Date();
  showEvalTrack:boolean = false;

  constructor(private dialog: MatDialog,
    private dialogService: DialogServiceService,
    private router: Router,private activatedRoute:ActivatedRoute, private fetchTracksService:FetchTracksService, private verifyUserService:VerifyUserService ) { }
// Active Route
  ngOnInit(): void {
    this.activatedRoute.paramMap.subscribe(params=>{
      this.trackId = <string>params.get('id');
      this.fetchTracksService.getTrackById(this.trackId).subscribe(data =>{
        this.currentTrack = data;
        if(this.currentDate.getDate() === new Date(this.currentTrack.end).getDate() && this.currentDate.getMonth() === new Date(this.currentTrack.end).getMonth()){
          this .showEvalTrack=true;
        }
        console.log("Date Comparision:" + new Date(this.currentTrack.end))
        console.log("Date Comparision:" + this.currentDate)
      });
      this.fetchTracksService.getTicketList().subscribe(ticket => this.ticketList = ticket);
      this.fetchTracksService.getActiveTickets().subscribe(activeTicket =>{
        this.activeTicketList = activeTicket
        console.log(this.activeTicketList);
      });

    });

    this.fetchTracksService.getTracks().subscribe(data => {
      this.tracks = data;
    });

    this.activatedRoute.paramMap.subscribe(params=>{
      this.user_email = <string>params.get('email');
      console.log("sideNav: "+this.user_email);
    });
    this.verifyUserService.verifyUser(this.user_email).subscribe(data => {
      this.currentUser = data;
      console.log("Current User: "+this.currentUser);
    });
    
  }

  trackDetails( track:ITrack){
    this.router.navigate(['/HTML',track._id])
  }

  alrtt(){
    this.dialogService.openConfirmDialog();
  }

  openStudyMaterial(){
    window.open('https://becurious.edcast.eu/journey/angular-course');
  }


}
