import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { IUser } from 'src/app/Interfaces/IUsers';
import { VerifyUserService } from 'src/app/Services/verify-user.service';
import {VerifyEvaluatorService} from '../../Services/verify-evaluator.service'

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {
  email:string;
  user;
  evaluator;
  errorMessage:string;
  
  constructor(private verifyUserService:VerifyUserService,private router:Router, private verifyEvaluatorService:VerifyEvaluatorService) { }

  ngOnInit(): void {
  }

  

  verifyLinker(){
    var email = ((document.getElementById("email") as HTMLInputElement).value);
      console.log(email);
      this.verifyUserService.verifyUser(email).subscribe(data =>{
      this.user=data;
      console.log(this.user);
    
      // this.router.navigate(['/home',this.user]);
      if(this.user.code!== 404 ){
        this.router.navigate(['/home',this.user.email]);
        
      }
      else{
        console.log("Invalid");
      }
      }
  );
 
  }

  verifyEvaluator(){
    var email = ((document.getElementById("email") as HTMLInputElement).value);
      console.log(email);
  //     this.VerifyEvaluatorService.verifyEvaluator(email).subscribe(data =>{
  //     this.evaluator=data;
  //     console.log("Evaluator: "+this.evaluator.email);
    
  //     // this.router.navigate(['/home',this.user]);
  //     if(this.user.code!== 404 ){
  //       this.router.navigate(['/eval',this.evaluator.email]);
        
  //     }
  //     else{
  //       console.log("Invalid");
  //     }
  //     }
  // );
  this.verifyEvaluatorService.verifyEvaluator(email).subscribe(data=>{
    this.evaluator = data;
    console.log("Evaluator: "+this.evaluator.email);
    if(this.evaluator.code!== 404 ){
      this.router.navigate(['/eval',this.evaluator.email]);
    }
    else{
            console.log("Invalid");
          }
    
    
  });
 
  }
 

}
