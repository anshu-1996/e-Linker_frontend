import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-htmlpage',
  templateUrl: './htmlpage.component.html',
  styleUrls: ['./htmlpage.component.scss']
})
export class HtmlpageComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
