import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { IUser } from 'src/app/Interfaces/IUsers';
import {FetchTracksService} from '../../Services/fetch-tracks.service';
import {VerifyUserService} from '../../Services/verify-user.service';


@Component({
  selector: 'app-sidenav',
  templateUrl: './sidenav.component.html',
  styleUrls: ['./sidenav.component.scss']
})
export class SidenavComponent implements OnInit {
  user_email;
  currentUser;

  constructor(private activatedRoute:ActivatedRoute, private verifyUserService:VerifyUserService) { }

  ngOnInit(): void {
    this.activatedRoute.paramMap.subscribe(params=>{
      this.user_email = <string>params.get('email');
      // console.log("sideNav: "+this.user_email);
    });
    this.verifyUserService.verifyUser(this.user_email).subscribe(data => {
      this.currentUser = data;
      // console.log("Current User: "+this.currentUser);
    });
    

  }

}
