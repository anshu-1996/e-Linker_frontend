import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { VerifyUserService } from 'src/app/Services/verify-user.service';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss']
})
export class HeaderComponent implements OnInit {
  user_email;
  currentUser;

  constructor(private activatedRoute:ActivatedRoute, private verifyUserService:VerifyUserService) { }

  ngOnInit(): void {
    this.activatedRoute.paramMap.subscribe(params=>{
      this.user_email = <string>params.get('email');
      console.log("sideNav: "+this.user_email);
    });
    this.verifyUserService.verifyUser(this.user_email).subscribe(data => {
      this.currentUser = data;
      console.log("Current User: "+this.currentUser);
    });
    

  }

}
