import { Component, OnInit, Inject } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { ActivatedRoute } from '@angular/router';
import { ILead } from 'src/app/Interfaces/ILead';
import { ITrack } from 'src/app/Interfaces/ITracks';
import {FetchTracksService} from '../../Services/fetch-tracks.service'

@Component({
  selector: 'app-helper-details',
  templateUrl: './helper-details.component.html',
  styleUrls: ['./helper-details.component.scss']
})
export class HelperDetailsComponent implements OnInit {

  trackId:string;
  public tracks = [];
  public helper = [];
  currentTrack:ITrack;
  // public userdetails!: ITrack;
  constructor(@Inject(MAT_DIALOG_DATA) public data,
  public dialogRef: MatDialogRef<HelperDetailsComponent>,
  private activatedRoute:ActivatedRoute,private fetchTracksService:FetchTracksService) { }

  ngOnInit(): void {
    // this.activatedRoute.paramMap.subscribe(params=>{
    //   this.trackId = <string>params.get('id');
    //   console.log(this.trackId);
    // });
    // this.fetchTracksService.getTrackById(this.trackId).subscribe(data =>{
    //   this.currentTrack = data;
    //   console.log(this.currentTrack.name);
    // });

    this.fetchTracksService.getTracks().subscribe(data => {
      this.tracks = data;
        // data.forEach(helper => {
        //   if(data.)
        // });
        this.helper = data[0].helper;
        console.log(this.helper);
    });

  }

  closeDialog() {
    this.dialogRef.close(false);
  }
}
