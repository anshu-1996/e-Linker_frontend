export interface Token {
  token:string,
  queueNumber:number
}
