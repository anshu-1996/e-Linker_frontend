import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class CardsService {

  public _url : "http://localhost:9080/api"
  constructor(private http: HttpClient) {
  }

  acceptTicket(email,token,comment): Observable<any>{
    return this.http.post<any>(`http://localhost:9080/api/eval/acceptToken/${token}`,{email:email,comment:comment});
  }
  confirmTicket(email,token): Observable<any>{
    return this.http.post<any>(`http://localhost:9080/api/eval/finish/${token}`,{email:email});
  }
  declineTicket(email,token): Observable<any>{
    return this.http.post<any>(`http://localhost:9080/api/eval/declineToken/${token}`,{email:email});
  }


}
