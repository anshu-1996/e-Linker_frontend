import { Injectable } from '@angular/core';
import {HttpClient,HttpHeaders} from '@angular/common/http';
import { Observable } from 'rxjs';
import { IUser } from '../Interfaces/IUsers';

@Injectable({
  providedIn: 'root'
})
export class VerifyUserService {
  private _url:string = "http://localhost:9080/api/linkerget";
  // private _url:string = "https://jsonplaceholder.typicode.com/users";

  constructor(private http: HttpClient) { }
  
  // Function To return The data from Json File
  verifyUser(email): Observable<IUser>{
    return this.http.post<IUser>(this._url,{email:email});
    
  }
}
