import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class VerifyEvaluatorService {

  private _url:string = "http://localhost:9080/api/eval/getEvalByEmail";
  // private _url:string = "https://jsonplaceholder.typicode.com/users";

  constructor(private http: HttpClient) { }
  
  // Function To return The data from Json File
  verifyEvaluator(email): Observable<any>{
    return this.http.get<any>(this._url+`/${email}`);
    
  }
}
