import { TestBed } from '@angular/core/testing';

import { VerifyEvaluatorService } from './verify-evaluator.service';

describe('VerifyEvaluatorService', () => {
  let service: VerifyEvaluatorService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(VerifyEvaluatorService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
